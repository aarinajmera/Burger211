import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.util.Locale;
import org.json.simple.JSONObject;
import java.net.URL;
import java.util.*;

// https://aa.usno.navy.mil/api/eclipses/solar/year?year=YEAR // Eclipse Website API

public class Main {

    public static void main(String[] args) throws Exception{

        int year;
        Scanner sc = new Scanner(System.in);
        System.out.println("Input year:");
        year = sc.nextInt();
        String eclipseURL = "https://aa.usno.navy.mil/api/eclipses/solar/year?year=" + year;
        URL url = new URL(eclipseURL);
        BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
        JSONParser jsonParser = new JSONParser();
        JSONObject myObject = (JSONObject)jsonParser.parse(br);
        JSONArray eclipseAll = (JSONArray)myObject.get("eclipses_in_year");
        System.out.println("Year:" + year);
        System.out.println("Number of eclipses:" + eclipseAll.size());

        for (int i = 0; i < eclipseAll.size(); i++){
            JSONObject e = (JSONObject)eclipseAll.get(i);
            String ev = (String)e.get("event");
            System.out.println(i + 1 + ". Event: " + ev);
        }

    }


}